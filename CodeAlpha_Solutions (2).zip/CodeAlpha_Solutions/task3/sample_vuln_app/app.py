# sample_vuln_app/app.py
from flask import Flask, request, render_template_string
import sqlite3, os

app = Flask(__name__)
DB = 'data.db'

def init_db():
    if not os.path.exists(DB):
        conn = sqlite3.connect(DB)
        conn.execute('CREATE TABLE users(id INTEGER PRIMARY KEY, username TEXT, secret TEXT)')
        conn.execute("INSERT INTO users(username, secret) VALUES('alice','alice_secret')")
        conn.commit()
        conn.close()

@app.route('/', methods=['GET','POST'])
def index():
    init_db()
    if request.method == 'POST':
        # Vulnerable to SQL injection (unsafe string interpolation)
        username = request.form.get('username','')
        conn = sqlite3.connect(DB)
        cur = conn.cursor()
        q = "SELECT secret FROM users WHERE username = '%s'" % username
        cur.execute(q)
        row = cur.fetchone()
        conn.close()
        if row:
            return f"Secret for {username}: {row[0]}"
        else:
            return 'No user found'
    return render_template_string('''
        <form method="post">
            Username: <input name="username"/><br/>
            <input type="submit" value="Lookup">
        </form>
    ''')

if __name__ == '__main__':
    app.run(debug=True)
