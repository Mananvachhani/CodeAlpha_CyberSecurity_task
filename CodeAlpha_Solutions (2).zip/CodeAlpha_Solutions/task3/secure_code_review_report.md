Secure Coding Review — Sample Report (Task 3)
--------------------------------------------

Target: sample_vuln_app/app.py (simple Flask app)

Summary of Findings:
1. SQL Injection (High)
   - Location: app.py, index() POST handler
   - Issue: User input is interpolated directly into SQL: "SELECT secret FROM users WHERE username = '%s'" % username
   - Impact: Attacker can extract secrets or modify DB contents.
   - Recommendation: Use parameterized queries or an ORM. Example:
     cur.execute('SELECT secret FROM users WHERE username = ?', (username,))

2. Debug Mode Enabled (Medium)
   - app.run(debug=True) enables debug UI which may expose secrets and arbitrary code execution in some Flask versions.
   - Recommendation: Never enable debug in production; use environment variables to control debug.

3. Missing Input Validation (Low-Medium)
   - No validation or rate-limiting on login/lookup forms; could be abused for enumeration.
   - Recommendation: Validate length, characters; implement rate-limiting and logging.

4. Insecure Error Handling / Information Exposure
   - Potential to leak detailed exceptions if debug True. Use custom error pages and logs.

Tools / Methods Used:
- Manual code review.
- Recommend static analysis: Bandit (for Python), Semgrep, and dependency checks via safety / pip-audit.

Remediation Steps (Suggested Patch):
- Replace raw SQL interpolation with parameterized queries.
- Disable debug in production and configure proper logging.
- Add input validation and rate-limiting, e.g., Flask-Limiter.
- Use Prepared Statements / ORM (SQLAlchemy).
- Add unit tests for security-sensitive flows.

Example fixed snippet:
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    cur.execute('SELECT secret FROM users WHERE username = ?', (username,))
